from procedures import *
import os
N=2**512
p = randprime(N)
q = randprime(N)

if not (is_prime(p) and is_prime(q)):
    raise ValueError('p or q not prime')
elif p == q:
    raise ValueError('p=q')

n=p*q
#print (n)
fi=(p-1)*(q-1)
#print (fi)
print("Public key e: ")
e= randprime(n)

while(True):
  p=gcd(e,fi)
  if p==1:
      break
  else:
      e=e+1

d=modinv(e,fi)

print (e)
print("Private Key d: ")
print (d)

dirpath = os.getcwd()
f = open(os.getcwd()+'/msg.txt','r') #Read the msg from msg.txt file
msg = f.read()
msg = msg.rstrip() #Read Message from the input file
m=int(msg)
print("Message: ", m)
r=  randprime(n) #2
while(True):
  p=gcd(r,n)
  if p==1:
      break
  else:
      r=r+1
print ("Blinding Factor: ",r)

invr=modinv(r,n)

print ("Blinding: ")
a=pow(r,e,n)
b=(m*a)
b=pow(b,1,n)

print (b)

print ("Signing: ")
s=pow(b,d,n)
print (s)
print ("unblinding: ")
l=(s*invr)
l=pow(l,1,n)
print (l)
print ("Verification: ")
v=pow(l,e,n)
print (v)

