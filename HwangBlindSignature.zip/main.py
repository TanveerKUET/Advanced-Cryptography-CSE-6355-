from procedures import *
import os

N=2**512
p = randprime(N)
q = randprime(N)

if not (is_prime(p) and is_prime(q)):
    raise ValueError('p or q not prime')
elif p == q:
    raise ValueError('p=q')

n=p*q
print('n :')
print (n)
fi=(p-1)*(q-1)
print('phi: ')
print (fi)
e=2

while(True):
    p=gcd(e,fi)
    if p==1:
        break
    else:
        e=e+1

d=modinv(e,fi)
dirpath = os.getcwd()
f = open(os.getcwd()+'/msg.txt','r') #Read the msg from msg.txt file
msg = f.read()
msg = msg.rstrip() #Read Message from the input file
m=int(msg)
#m=int(input("raw message m: "))
print("message: ", m)

r1=blindingfactor(200)
r2=blindingfactor(201)

if r1 == r2:
    raise ValueError('r1 = r2')

a1 = randprime(2**24)
a2 = randprime(2**24)
    #a1 = randprime(100)
    #a2 = randprime(120)

if not (is_prime(a1) and is_prime(a2)):
    raise ValueError('a1 or a2 not prime')
elif p == q:
    raise ValueError('a1 = a2')

print("Now blinding the message: ")
bm1=pow(r1,e,n)*pow(m,a1,n)
bm1=pow(bm1,1,n)

bm2=pow(r2,e,n)*pow(m,a2,n)
bm2=pow(bm2,1,n)

print("bm1: " , bm1)
print("bm2: " , bm2)

b1 = randprime(2**12)
b2 = randprime(2**12)

if not (is_prime(b1) and is_prime(b2)):
    raise ValueError('b1 or b2 not prime')
elif b1 == b2:
    raise ValueError('b1 = b2')

print("Signing the message: ")
sm1=pow(bm1,b1*d,n)
sm2=pow(bm2,b2*d,n)

print(sm1)
print(sm2)

print("UnBlinding Phase: ")
invr1=pow(r1,b1,n)
invr2=pow(r2,b2,n)

invr1 = modinv(invr1,n)
invr2 = modinv(invr2,n)

um1=(sm1*invr1)%n

um2=(sm2*invr2)%n

g,w,u = egcd(a1*b1,a2*b2)

print("w: ", w)
print("u: ", u)

if(w<0):
    s1 = pow(um1,-w,n)
    s1 = modinv(s1,n)
else:
    s1=pow(um1,w,n)

if(u<0):
    s2 = pow(um2,-u,n)
    s2 = modinv(s2,n)
else:
    s2=pow(um2,u,n)

um = pow(s1*s2,1,n)

print("unblinded: ", um)

print("Verifying Phase: ")
vm=pow(um,e,n)

print ("vm",vm)

