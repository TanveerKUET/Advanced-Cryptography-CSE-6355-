from procedures import *
import os

dirpath = os.getcwd()
f = open(os.getcwd()+'/msg.txt','r') #Read the msg from msg.txt file
msg = f.read()
msg = msg.rstrip()#9999999999999999999999999999999999999999;
msg=int(msg)

print ("Original Message :", msg)

P = random.randint(pow(10, 20), pow(10, 50))
g = random.randint(2, P)
x = gen_key(P)    # Private key for receiver
Y = pow(g, x, P)
print ("P :",P)
print ("g : ", g)
print ("Y : ", Y)

print ("1st Encryption result: ")
c2, c1 = encrypt(msg, P, Y, g)
print ("c1,c2",c1,c2)

print ("2nd Encryption result: ")
c2, c11 = encrypt(c2, P, Y, g)
print ("c1,c2",c1,c2)


de_msg = decrypt(c2, pow(c1*c11,1,P), x, P)
print ("Decrypted Message :", de_msg)
