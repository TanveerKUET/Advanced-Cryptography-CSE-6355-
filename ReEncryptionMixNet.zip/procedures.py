import random

def gcd(a, b):
	if a < b:
		return gcd(b, a)
	elif a % b == 0:
		return b;
	else:
		return gcd(b, a % b)

def egcd(a, b):
    if a == 0:
        return (b, 0, 1)
    else:
        g, y, x = egcd(b % a, a)
        return (g, x - (b // a) * y, y)

def modinv(a, m):
    g, x, y = egcd(a, m)
    if g != 1:
        raise Exception('invalid modular inverse ')
    else:
        return (x+m) % m

def gcd(a, b):
	if a < b:
		return gcd(b, a)
	elif a % b == 0:
		return b;
	else:
		return gcd(b, a % b)

# Generating large random numbers
def gen_key(q):

	key = random.randint(pow(10, 20), q)
	while gcd(q, key) != 1:
		key = random.randint(pow(10, 20), q)

	return key


# Asymmetric encryption
def encrypt(msg, P, Y, g):

	r = 9    #gen_key(P)# Private key for sender
	s = pow(Y, r, P)
	c1 = pow(g, r, P) # y1 = ( alpha^k ) mod P

	#print("g^k used : ", c1)
	#print("g^ak used : ", s)

	c2 = pow(s * msg,1,P)  #y2 = ( m * beta^k ) mod P

	return c2, c1

def decrypt(en_msg, c1, x, P):

	h = pow(c1, x, P)
	h = modinv(h,P)
	dr_msg = pow(en_msg*h,1,P)

	return dr_msg
